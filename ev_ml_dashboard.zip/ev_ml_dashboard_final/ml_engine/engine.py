import sys,json,os,hashlib
from datetime import datetime,timezone
import numpy as np,pandas as pd,joblib
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split,KFold,cross_val_score
from sklearn.linear_model import LinearRegression,Ridge,ElasticNet
from sklearn.ensemble import RandomForestRegressor,GradientBoostingRegressor,ExtraTreesRegressor
from sklearn.metrics import mean_absolute_error,mean_squared_error,r2_score
ROOT=os.path.abspath(os.path.join(os.path.dirname(__file__),"..")); MD=os.path.join(ROOT,"models"); LG=os.path.join(ROOT,"logs"); os.makedirs(MD,exist_ok=True); os.makedirs(LG,exist_ok=True); T="Energy_Consumed_kWh"; C=["City","Vehicle_Type","Payment_Method"]; N=["duration_minutes","start_hour","start_sin","start_cos"]; FACT={"Linear Regression":lambda:LinearRegression(),"Ridge":lambda:Ridge(alpha=1),"Elastic Net":lambda:ElasticNet(alpha=.05,l1_ratio=.5,max_iter=10000,random_state=42),"Random Forest":lambda:RandomForestRegressor(n_estimators=200,random_state=42,n_jobs=-1),"Gradient Boosting":lambda:GradientBoostingRegressor(random_state=42,n_estimators=150),"Extra Trees":lambda:ExtraTreesRegressor(n_estimators=200,random_state=42,n_jobs=-1)}
def load(p):
 d=pd.read_csv(p); d[T]=pd.to_numeric(d[T],errors="coerce"); s=pd.to_datetime(d["Charging_Start_Time"],errors="coerce"); e=pd.to_datetime(d["Charging_End_Time"],errors="coerce"); dur=(e-s).dt.total_seconds()/60; dur=dur.where(dur>=0,dur+1440); d["duration_minutes"]=dur.fillna(0); d["start_hour"]=s.dt.hour.fillna(0); d["start_sin"]=np.sin(2*np.pi*d.start_hour/24); d["start_cos"]=np.cos(2*np.pi*d.start_hour/24); return d.dropna(subset=[T])
def pipe(n):
 pre=ColumnTransformer([("cat",Pipeline([("imp",SimpleImputer(strategy="most_frequent")),("oh",OneHotEncoder(handle_unknown="ignore"))]),C),("num",Pipeline([("imp",SimpleImputer(strategy="median"))]),N)]); return Pipeline([("pre",pre),("model",FACT[n]())])
def reg(p,sel=None):
 d=load(p); X,y=d[C+N],d[T]; xt,xv,yt,yv=train_test_split(X,y,test_size=.2,random_state=42); out=[]
 for n in sel or FACT:
  m=pipe(n); m.fit(xt,yt); pr=m.predict(xv); cv=float(np.sqrt(-cross_val_score(m,X,y,cv=KFold(5,shuffle=True,random_state=42),scoring="neg_mean_squared_error").mean())); out.append({"model":n,"mae":round(float(mean_absolute_error(yv,pr)),4),"rmse":round(float(np.sqrt(mean_squared_error(yv,pr))),4),"r2":round(float(r2_score(yv,pr)),4),"cv_rmse":round(cv,4)}); joblib.dump(m,os.path.join(MD,n.lower().replace(" ","_")+".joblib"))
 meta={"version":"1.0","trained_at":datetime.now(timezone.utc).isoformat(),"dataset_rows":len(d),"features":C+N,"target":T,"excluded_features":["Cost_INR"],"test_size":.2,"random_state":42,"dataset_sha256_16":hashlib.sha256(open(p,"rb").read()).hexdigest()[:16],"models":sorted(out,key=lambda x:x["mae"])}; json.dump(meta,open(os.path.join(MD,"model_registry.json"),"w"),indent=2); open(os.path.join(LG,"audit_log.jsonl"),"a").write(json.dumps({"event":"train","timestamp":meta["trained_at"],"models":sel or list(FACT)})+"\n"); return meta
def inp(x):
 d=pd.DataFrame([{"City":x.get("city","Delhi"),"Vehicle_Type":x.get("vehicle_type","Car"),"Payment_Method":x.get("payment_method","UPI"),"Charging_Start_Time":x.get("start_time","2026-01-01 10:00"),"Charging_End_Time":x.get("end_time","2026-01-01 12:00")}]); return load_tmp(d)
def load_tmp(d):
 s=pd.to_datetime(d.Charging_Start_Time); e=pd.to_datetime(d.Charging_End_Time); dur=(e-s).dt.total_seconds()/60; dur=dur.where(dur>=0,dur+1440); d["duration_minutes"]=dur; d["start_hour"]=s.dt.hour; d["start_sin"]=np.sin(2*np.pi*d.start_hour/24); d["start_cos"]=np.cos(2*np.pi*d.start_hour/24); return d
def load_registry(p):
 rp=os.path.join(MD,"model_registry.json")
 if not os.path.exists(rp):
  return reg(p)
 try:
  with open(rp,"r",encoding="utf-8") as f:
   meta=json.load(f)
 except Exception:
  meta={}
 if not isinstance(meta,dict) or "models" not in meta or not isinstance(meta.get("models"),list) or not meta["models"]:
  return reg(p)
 return meta

def main():
 a=sys.argv[1]; p=sys.argv[sys.argv.index("--data")+1]; payload=json.load(sys.stdin) if not sys.stdin.isatty() else {}; meta=load_registry(p)
 if a=="train": print(json.dumps(reg(p,payload.get("models")))); return
 if a in ["models","analytics"]: print(json.dumps(meta if a=="models" else {"registry":meta,"shape":list(pd.read_csv(p).shape)})); return
 if a=="dataset":
  d=pd.read_csv(p); print(json.dumps({"rows":len(d),"summary":[{"column":c,"dtype":str(d[c].dtype),"missing":int(d[c].isna().sum()),"unique":int(d[c].nunique())} for c in d.columns],"preview":d.head(20).fillna("").to_dict("records")})); return
 if a=="predict":
  m=payload.get("model",meta["models"][0]["model"]); names=[x["model"] for x in meta["models"]]; z=inp(payload);
  if m=="All Models": print(json.dumps({"predictions":[{"model":n,"prediction_kwh":round(float(joblib.load(os.path.join(MD,n.lower().replace(" ","_")+".joblib")).predict(z[C+N])[0]),3)} for n in names]})); return
  f=os.path.join(MD,m.lower().replace(" ","_")+".joblib");
  if not os.path.exists(f): reg(p,[m])
  print(json.dumps({"model":m,"prediction_kwh":round(float(joblib.load(f).predict(z[C+N])[0]),3)})); return
 if a=="governance":
  d=pd.read_csv(p); checks=[{"check":"Schema / target","status":"PASS" if T in d else "FAIL","detail":T},{"check":"Missing values","status":"PASS" if int(d.isna().sum().sum())==0 else "WARNING","detail":f"{int(d.isna().sum().sum())} missing cells"},{"check":"Duplicate rows","status":"PASS" if int(d.duplicated().sum())==0 else "WARNING","detail":f"{int(d.duplicated().sum())} duplicates"},{"check":"Target leakage","status":"PASS","detail":"Cost_INR excluded"},{"check":"Reproducibility","status":"PASS","detail":"random_state=42 + dataset fingerprint"},{"check":"Model registry","status":"PASS","detail":f"{len(meta['models'])} models"}]; issues=[]; print(json.dumps({"status":"WARNING" if any(x["status"]=="WARNING" for x in checks) else "PASS","checks":checks,"issues":issues,"registry":meta,"limitations":["Proof-of-concept governance layer, not production certification.","Dataset is small.","Low R² should be interpreted with care.","Cost_INR is excluded to prevent leakage."]})); return
 raise SystemExit("Unknown action")
main()
