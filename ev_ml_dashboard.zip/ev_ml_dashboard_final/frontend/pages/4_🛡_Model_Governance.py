import streamlit as st, requests, pandas as pd, os

st.markdown(
    """
    <style>
    .stApp {
        background: linear-gradient(135deg, #f4f7fb 0%, #eef4ff 100%);
        color: #102a43;
    }
    h1 {
        color: #0f172a !important;
        font-weight: 800;
        letter-spacing: 0.02em;
    }
    h2 {
        color: #1d4ed8 !important;
        font-weight: 700;
        margin-top: 1.5rem;
    }
    .stAlert, .stSuccess, .stWarning, .stInfo {
        border-radius: 12px;
        box-shadow: 0 8px 24px rgba(15, 23, 42, 0.08);
    }
    .stDataFrame {
        border-radius: 14px;
        overflow: hidden;
        box-shadow: 0 10px 24px rgba(15, 23, 42, 0.08);
    }
    [data-testid="stMetricValue"] {
        color: #0f172a !important;
        font-weight: 700;
    }
    [data-testid="stMetricLabel"] {
        color: #475569 !important;
    }
    .block-container {
        padding-top: 2rem;
        padding-bottom: 2rem;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

API = os.getenv("EV_API_URL", "http://localhost:5000/api")

@st.cache_data(ttl=300)
def fetch_governance():
    response = requests.get(API + "/governance", timeout=60)
    response.raise_for_status()
    return response.json()

st.title("🛡️ Model Governance")

with st.spinner("Loading governance data..."):
    g = fetch_governance()

if g.get("status") == "PASS":
    st.success(f"Governance status: {g['status']}")
else:
    st.warning(f"Governance status: {g.get('status', 'UNKNOWN')}")

checks = pd.DataFrame(g.get("checks", []))
if not checks.empty:
    st.dataframe(checks, use_container_width=True, hide_index=True)
    a, b, c = st.columns(3)
    a.metric("Checks", len(checks))
    b.metric("Warnings", int((checks["status"] == "WARNING").sum()))
    c.metric("Registered Models", len(g.get("registry", {}).get("models", [])))
else:
    st.info("No governance checks returned from the backend.")

st.subheader("Model Registry")
model_registry = g.get("registry", {})
features = model_registry.get("features", [])
excluded = model_registry.get("excluded_features", [])

st.markdown(
    f"""
    - **Version:** {model_registry.get('version', 'N/A')}
    - **Trained at:** {model_registry.get('trained_at', 'N/A')}
    - **Dataset rows:** {model_registry.get('dataset_rows', 'N/A')}
    - **Dataset fingerprint:** {model_registry.get('dataset_sha256_16', 'N/A')}
    - **Target:** {model_registry.get('target', 'N/A')}
    - **Features:** {', '.join(features) if isinstance(features, list) and features else 'N/A'}
    - **Excluded features:** {', '.join(excluded) if isinstance(excluded, list) and excluded else 'N/A'}
    """
)

st.subheader("Automated risk flags")
issues = g.get("issues", [])
if issues:
    for issue in issues:
        st.warning(issue)
else:
    st.success("No additional automated risk flags.")

st.subheader("Known limitations")
for limitation in g.get("limitations", []):
    st.write(f"• {limitation}")

st.subheader("Lifecycle")
st.write("Validate data → prevent leakage → train reproducibly → evaluate → register → log predictions → re-check after changes.")