import streamlit as st,requests,os
API=os.getenv("EV_API_URL","http://localhost:5000/api"); st.title("⚡ Live Inference & Training Lab"); ms=requests.get(API+"/models",timeout=60).json()["models"]; names=[x["model"] for x in ms]; model=st.selectbox("Model",names+["All Models"]); city=st.selectbox("City",["Delhi","Mumbai","Bangalore","Chennai","Hyderabad","Pune","Kolkata"]); vehicle=st.selectbox("Vehicle",["Car","Bike","Bus","Truck"]); payment=st.selectbox("Payment",["UPI","Credit Card","Debit Card","Cash"]); start=st.text_input("Start", "2026-01-01 10:00"); end=st.text_input("End","2026-01-01 12:00")
if st.button("🔮 Predict",type="primary"):
 r=requests.post(API+"/predict",json={"model":model,"city":city,"vehicle_type":vehicle,"payment_method":payment,"start_time":start,"end_time":end},timeout=60).json();
 if "predictions" in r: st.dataframe(r["predictions"],use_container_width=True,hide_index=True); st.bar_chart({x["model"]:x["prediction_kwh"] for x in r["predictions"]})
 else: st.metric("Predicted Energy",f'{r["prediction_kwh"]:.2f} kWh')
st.divider(); st.subheader("🔥 Live Training Lab"); selected=st.multiselect("Models to retrain",names,default=names)
if st.button("Train selected models"):
 if selected: r=requests.post(API+"/train",json={"models":selected},timeout=300).json(); st.success("Training completed"); st.dataframe(r["models"],use_container_width=True,hide_index=True)
 else: st.warning("Select at least one model.")